from __future__ import annotations

from src.engine.execution_event import ExecutionEvent
from src.engine.execution_event_emitter import ExecutionEventEmitter
from src.engine.node_execution_runtime import Artifact, NodeExecutionRuntime
from src.platform.plugin_result import PluginResult


class DummyProviderExecutor:
    def execute(self, request):
        raise RuntimeError("not used in this test")


def test_execution_event_now_builds_event():
    event = ExecutionEvent.now(
        "node_started",
        {"x": 1},
        execution_id="exec-1",
        node_id="node-1",
    )

    assert event.type == "node_started"
    assert event.execution_id == "exec-1"
    assert event.node_id == "node-1"
    assert event.payload == {"x": 1}
    assert isinstance(event.timestamp_ms, int)


def test_execution_event_emitter_collects_events(tmp_path):
    event_file = tmp_path / "events.jsonl"
    emitter = ExecutionEventEmitter(str(event_file))

    emitter.emit(
        ExecutionEvent.now(
            "warning",
            {"message": "x"},
            execution_id="exec-2",
            node_id="n1",
        )
    )

    events = emitter.get_events()
    assert len(events) == 1
    assert events[0].type == "warning"
    assert events[0].execution_id == "exec-2"
    assert event_file.exists()


def test_runtime_emits_artifact_preview_event():
    runtime = NodeExecutionRuntime(
        provider_executor=DummyProviderExecutor(),
        plugin_registry={},
        event_emitter=ExecutionEventEmitter(event_file=None),
    )
    runtime.set_execution_id("exec-preview")

    artifacts = [
        Artifact(
            type="preview",
            name="sample_preview",
            data={"samples": [1, 2, 3]},
            metadata={"source": "test"},
        )
    ]

    runtime._emit_artifact_preview_events("node-a", artifacts)

    events = runtime.get_execution_events()
    assert len(events) == 1
    assert events[0].type == "artifact_preview"
    assert events[0].execution_id == "exec-preview"
    assert events[0].node_id == "node-a"
    assert events[0].payload["artifact_name"] == "sample_preview"


def test_runtime_emits_progress_event_from_plugin_result():
    runtime = NodeExecutionRuntime(
        provider_executor=DummyProviderExecutor(),
        plugin_registry={},
        event_emitter=ExecutionEventEmitter(event_file=None),
    )
    runtime.set_execution_id("exec-progress")

    result = PluginResult(
        output={"result": "ok"},
        trace={"progress": {"processed": 3, "total": 10}},
    )

    runtime._emit_progress_event_from_plugin_result(
        node_id="node-b",
        plugin_id="demo.plugin",
        plugin_result=result,
    )

    events = runtime.get_execution_events()
    assert len(events) == 1
    assert events[0].type == "progress"
    assert events[0].execution_id == "exec-progress"
    assert events[0].node_id == "node-b"
    assert events[0].payload["plugin_id"] == "demo.plugin"
    assert events[0].payload["processed"] == 3
    assert events[0].payload["total"] == 10