﻿Return exactly: OK
